package com.cg.transaction.entities;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Capstore {
@Id
private long accNo;
private double balance;
public Capstore() {
	super();
	// TODO Auto-generated constructor stub
}
public Capstore(long accNo, double balance) {
	super();
	this.accNo = accNo;
	this.balance = balance;
}
public long getAccNo() {
	return accNo;
}
public void setAccNo(long accNo) {
	this.accNo = accNo;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
} 
}
