package com.cg.transaction.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "bankingdetails")
public class NetBanking {
	
	@Id
	private String userId;
	private String password;
	private String bankName;
	private int amount;

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getBankType() {
		return bankName;
	}

	public void setBankType(String bankType) {
		this.bankName= bankType;
	}

	public NetBanking() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NetBanking(String userId, String password,String bankName,int amount) {
		super();
		this.userId = userId;
		this.password = password;
		this.bankName=bankName;
		this.amount=amount;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
