package com.cg.transaction.dao;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.transaction.entities.Capstore;
import com.cg.transaction.entities.Transaction;
@Repository
public interface Transactiondao extends JpaRepository<Transaction,Long>{
@Query("update data set amount=:userFinalBal")
List<Transaction> findtrans(@Param("userFinalBal") double userFinalBal);

	

}
