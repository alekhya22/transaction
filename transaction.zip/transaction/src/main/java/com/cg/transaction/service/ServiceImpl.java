package com.cg.transaction.service;

import java.util.List;

import com.cg.transaction.entities.NetBanking;
import com.cg.transaction.entities.Transaction;

public interface ServiceImpl {

	public List<Transaction> insertTransaction(Transaction transaction);

	public List<NetBanking> insertNetBanking(NetBanking netbanking);
	public void userAmount(int amount);
	public void updateRevenue(long cardNo,int amount);
	
	
}
