package com.cg.transaction.dao;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.transaction.entities.Capstore;
import com.cg.transaction.entities.NetBanking;
@Repository
public interface CapstoreDao extends JpaRepository<Capstore,Long>{
@Query("update capstore set balance=:destFinalBal")
List<Capstore> findcust(@SuppressWarnings("deprecation") @Param("destFinalBal") double destFinalBal);

}
