package com.cg.transaction.service;

import java.util.List;
import java.util.Optional;

import org.jboss.logging.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.transaction.dao.CapstoreDao;
import com.cg.transaction.dao.NetBankingDao;
import com.cg.transaction.dao.Transactiondao;
import com.cg.transaction.entities.Capstore;
import com.cg.transaction.entities.NetBanking;
import com.cg.transaction.entities.Transaction;

@Service
public class IService implements ServiceImpl {
	@Autowired
	Transactiondao transactiondao;
	@Autowired
	NetBankingDao netBankingDao;
	@Autowired
	CapstoreDao capstoreDao;

	@Override
	public List<Transaction> insertTransaction(Transaction transaction) {
		transactiondao.save(transaction);
		updateRevenue(transaction.getCardNo(), transaction.getAmount());
		return transactiondao.findAll();

	}

	@Override
	public List<NetBanking> insertNetBanking(NetBanking netbanking) {
		// TODO Auto-generated method stub
		netBankingDao.save(netbanking);
		return netBankingDao.findAll();
	}

	@Override
	public void updateRevenue(long cardNo, int amount) {
		Transaction source = transactiondao.findById(cardNo).get();
		long appaccNo = 123456789;
		Capstore dest = capstoreDao.findById(appaccNo).get();

		int userInitialBal = source.getAmount();
		int userFinalBal = userInitialBal - amount;
		double capBal = dest.getBalance();
		double destFinalBal = capBal + amount;
		source.setAmount(userFinalBal);
		dest.setBalance(destFinalBal);
	transactiondao.findtrans(userFinalBal);
		transactiondao.save(source);
		capstoreDao.findcust(destFinalBal);
		capstoreDao.save(dest);
	}

	@Override
	public void userAmount(int amount) {
		// TODO Auto-generated method stub

	}

}
